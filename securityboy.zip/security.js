
//==============FUNCTION NOMOR NAMA PW ===========//
async function isAuthorizedUser(phoneNumber, name, password) {
    const databaseURL = 'https://raw.githubusercontent.com/AANCODE444/Aan-V4/refs/heads/main/user_data.json'; // Ganti dengan URL Anda
    try {
        const response = await axios.get(databaseURL);
        const userData = response.data;

        // Cek apakah nomor terdaftar
        if (!userData[phoneNumber]) {
            console.log(chalk.red('Nomor tidak terdaftar.'));
            return false;
        }

        const user = userData[phoneNumber];

        // Verifikasi nama dan password
        if (user.name === name && user.password === password) {
            console.log(chalk.green('Data valid! Script dapat dijalankan.'));
            return true;
        } else {
            console.log(chalk.red('Nama atau password salah.'));
            return false;
        }
    } catch (error) {
        console.error(chalk.red('Error fetching user data:'), error.message);
        return false;
    }
}


//==========FUNCTION NOMOR NAMA PW KODE OTP TELE =======//

const TELEGRAM_BOT_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'; // Ganti dengan Token Bot Telegram

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function askQuestion(query) {
    return new Promise(resolve => rl.question(query, resolve));
}

// Fungsi mengirim OTP ke Telegram
async function sendTelegramOTP(telegramID) {
    const otp = Math.floor(100000 + Math.random() * 900000).toString(); // Generate 6 digit OTP
    const message = `🔐 Kode OTP Anda: *${otp}* \nGunakan kode ini untuk verifikasi login.`;

    try {
        const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
        await axios.post(url, {
            chat_id: telegramID,
            text: message,
            parse_mode: 'Markdown'
        });
        console.log(chalk.green(`OTP dikirim ke Telegram ID: ${telegramID}`));
        return otp;
    } catch (error) {
        console.error(chalk.red('Gagal mengirim OTP ke Telegram:'), error.message);
        return null;
    }
}

// Fungsi verifikasi pengguna + OTP
async function isAuthorizedUser(phoneNumber, name, inputPassword, telegramID) {
    const databaseURL = 'https://raw.githubusercontent.com/AANCODE444/Aan-V4/refs/heads/main/user_data.json';
    try {
        const response = await axios.get(databaseURL);
        const userData = response.data;

        if (!userData[phoneNumber]) {
            console.log(chalk.red('\nNomor tidak terdaftar.'));
            return false;
        }

        const user = userData[phoneNumber];

        // Verifikasi nama dan password
        if (user.name !== name || user.password !== inputPassword) {
            console.log(chalk.red('\nNama atau password salah.'));
            return false;
        }

        // Kirim OTP ke Telegram
        const otpSent = await sendTelegramOTP(telegramID);
        if (!otpSent) return false;

        // Minta pengguna memasukkan OTP
        const otpInput = await askQuestion(chalk.yellow("\nMasukkan kode OTP yang dikirim ke Telegram: "));

        if (otpInput !== otpSent) {
            console.log(chalk.red("\nOTP salah!"));
            return false;
        }

        console.log(chalk.green('\nAkses diberikan!'));
        return true;
    } catch (error) {
        console.error(chalk.red('\nError fetching user data:'), error.message);
        return false;
    }
}

//============FUNCTION NOMOR PW ===========//

async function isAuthorizedNumber(phoneNumber) {
   const databaseURL = 'https://raw.githubusercontent.com/CupenCrew/Aan-V4/refs/heads/main/dtbs.json';
    try {
        const response = await axios.get(databaseURL);
        const authorizedNumbers = response.data.data;
        return authorizedNumbers.includes(phoneNumber);
    } catch (error) {
        console.error('Error fetching database:', error.message);
        return
    }
}

async function validatePassword(inputPassword) {
    const passURL = 'https://raw.githubusercontent.com/CupenCrew/Aan-V4/refs/heads/main/key.txt';
    try {
        const response = await axios.get(passURL);
        const storedPassword = response.data.trim();
        return inputPassword === storedPassword;
    } catch (error) {
        console.error('Error fetching password:', error.message);
        return false;
    }
}
//============FUNCTION CONTROL SCRIPT======÷==÷÷÷÷÷÷//
async function isScriptAllowed() {
    const controlURL = 'https://raw.githubusercontent.com/AANCODE444/Aan-V4/refs/heads/main/control.txt';
    try {
        const response = await axios.get(controlURL);
        const status = response.data.trim().toLowerCase();
        return status === 'on';
    } catch (error) {
        console.error(chalk.red('Error fetching control status:'), error.message);
        return false;
    }
}

//============FUNCTION DETECT TOKEN TELE==========//
const axios = require("axios");
const { BOT_TOKEN } = require("./config"); // Ambil token dari config.js

// URL tokens.json di GitHub
const databaseURL = "https://raw.githubusercontent.com/AANCODE444/Aan-V4/main/tokens.json";

async function isTokenRegistered(token) {
    try {
        const response = await axios.get(databaseURL);
        const tokenData = response.data;

        if (!tokenData.tokens.includes(token)) {
            console.log("❌ BOT_TOKEN tidak terdaftar! Script dihentikan.");
            process.exit(1); // Keluar dari script
        } else {
            console.log("✅ BOT_TOKEN valid! Script berjalan.");
        }
    } catch (error) {
        console.error("❌ Gagal mengambil data token:", error.message);
        process.exit(1);
    }
}

// Panggil function sebelum menjalankan bot
isTokenRegistered(BOT_TOKEN);

//===========$FUNCTION PW DETEC TOKEN TELE=============//
const databaseURL = "https://raw.githubusercontent.com/AANCODE444/Aan-V4/main/tokens.json";

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
function askPassword(question) {
    return new Promise((resolve) => {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
            terminal: true
        });

        rl.question(question, (password) => {
            rl.close();
            resolve(password);
        });
    });
}
async function checkAccess(token, inputPassword) {
    try {
        const response = await axios.get(databaseURL);
        const data = response.data;

        // Cek password utama
        if (data.password !== inputPassword) {
            console.log("❌ Password salah! Script dihentikan.");
            process.exit(1);
        }

        // Cek apakah token terdaftar
        if (!data.tokens.includes(token)) {
            console.log("❌ BOT_TOKEN tidak terdaftar! Script dihentikan.");
            process.exit(1);
        }

        console.log("✅ Password & BOT_TOKEN valid! Script berjalan.");
    } catch (error) {
        console.error("❌ Gagal mengambil data:", error.message);
        process.exit(1);
    }
}

(async () => {
    const password = await askPassword("Masukkan password: ");
    await checkAccess(BOT_TOKEN, password);
})();
