
//==========ADD DB NOMOR NAMA PW===========//
case 'adddb1': {
 if (!q) return m.reply('❌ Anda harus mengirimkan data dalam format: nomor|nama|password.');

 const [phoneNumber, name, password] = q.split('|').map(item => item.trim()); // Pisahkan input berdasarkan '|'

 if (!phoneNumber || !name || !password) {
 return m.reply('❌ Format tidak valid. Gunakan format: nomor|nama|password.');
 }

 const GITHUB_TOKEN = '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'; // Ganti dengan token GitHub Anda
 const REPO_OWNER = 'AANCODE444'; // Ganti dengan username GitHub Anda
 const REPO_NAME = 'Aan-V4'; // Ganti dengan nama repositori Anda
 const FILE_PATH = 'user_data.json'; // Path ke file JSON di repositori Anda

 try {
 // Ambil data JSON dari GitHub
 const response = await fetch(`https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/main/${FILE_PATH}`);
 const jsonData = await response.json();

 // Validasi apakah struktur data sudah benar
 if (!jsonData || typeof jsonData !== 'object') {
 return m.reply('❌ Struktur data tidak valid.');
 }

 // Cek apakah nomor sudah ada di database
 if (jsonData[phoneNumber]) {
 return m.reply(`❌ Nomor ${phoneNumber} sudah ada di database.`);
 }

 // Tambahkan data baru ke JSON
 jsonData[phoneNumber] = { name, password };

 // Encode data JSON menjadi base64 untuk diupload ke GitHub
 const updatedData = JSON.stringify(jsonData, null, 2); // Format JSON dengan indentation 2 spasi
 const base64Content = Buffer.from(updatedData).toString('base64'); // Encode ke base64

 // Ambil SHA dari file GitHub yang ada
 const shaResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`);
 const shaData = await shaResponse.json();
 const currentSHA = shaData.sha; // SHA file yang ada

 // Update file di GitHub
 const updateResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
 method: 'PUT',
 headers: {
 'Authorization': `Bearer ${GITHUB_TOKEN}`,
 'Content-Type': 'application/json',
 },
 body: JSON.stringify({
 message: `Menambahkan nomor ${phoneNumber} ke database`,
 content: base64Content,
 sha: currentSHA, // SHA file yang ada
 }),
 });

 const updateResult = await updateResponse.json();

 if (updateResponse.status === 200) {
 return m.reply(`✅ Nomor ${phoneNumber} dengan nama "${name}" dan password "${password}" berhasil ditambahkan ke database.`);
 } else {
 throw new Error(`Error menambahkan data: ${updateResult.message}`);
 }

 } catch (error) {
 console.error(error);
 return m.reply(`❌ Error: ${error.message}`);
 }
}
break;

//============ADD DB NOMOR ONLY==============//
case 'adddb':
{
 if (!q) return m.reply('❌ Anda harus mengirimkan nomor yang akan ditambahkan ke database.');

 const phoneNumber = q.trim(); // Nomor yang ingin ditambahkan
 const GITHUB_TOKEN = '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'; // Ganti dengan token GitHub Anda
 const REPO_OWNER = 'AANCODE444'; // Ganti dengan username GitHub Anda
 const REPO_NAME = 'Aan-V4'; // Ganti dengan nama repositori Anda
 const FILE_PATH = 'dtbs.json'; // Path ke file JSON di repositori Anda

 try {
 // Ambil data JSON dari GitHub
 const response = await fetch(`https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/main/${FILE_PATH}`);
 const jsonData = await response.json();

 // Validasi apakah data sudah ada
 if (!jsonData || !jsonData.data || !Array.isArray(jsonData.data)) {
 return m.reply('❌ Struktur data tidak valid.');
 }

 // Cek apakah nomor sudah ada di database
 if (jsonData.data.includes(phoneNumber)) {
 return m.reply(`❌ Nomor ${phoneNumber} sudah ada di database.`);
 }

 // Tambahkan nomor baru ke array data
 jsonData.data.push(phoneNumber); // Nomor ditambahkan di akhir array

 // Encode data JSON menjadi base64 untuk diupload ke GitHub
 const updatedData = JSON.stringify(jsonData, null, 2); // Format JSON dengan indentation 2 spasi
 const base64Content = Buffer.from(updatedData).toString('base64'); // Encode ke base64

 // Ambil SHA dari file GitHub yang ada
 const shaResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`);
 const shaData = await shaResponse.json();
 const currentSHA = shaData.sha; // SHA file yang ada

 // Update file di GitHub
 const updateResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
 method: 'PUT',
 headers: {
 'Authorization': `Bearer ${GITHUB_TOKEN}`,
 'Content-Type': 'application/json',
 },
 body: JSON.stringify({
 message: `Menambahkan nomor ${phoneNumber} ke database`,
 content: base64Content,
 sha: currentSHA, // SHA file yang ada
 }),
 });

 const updateResult = await updateResponse.json();

 if (updateResponse.status === 200) {
 return m.reply(`✅ Nomor ${phoneNumber} berhasil ditambahkan ke database.`);
 } else {
 throw new Error(`Error menambahkan nomor: ${updateResult.message}`);
 }

 } catch (error) {
 console.error(error);
 return m.reply(`❌ Error: ${error.message}`);
 }
}
break;